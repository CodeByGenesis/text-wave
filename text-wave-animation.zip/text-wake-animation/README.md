# Text wake animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/CodeByGenesis/pen/dyBoqgm](https://codepen.io/CodeByGenesis/pen/dyBoqgm).

